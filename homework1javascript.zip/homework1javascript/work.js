
let phone=119.95;
let tax=0.05;
let NumberOfPhones=30;
let PriceOfPhonesBeforeTax=phone*NumberOfPhones;
let Total=PriceOfPhonesBeforeTax*tax;
let priceTotal=Total+PriceOfPhonesBeforeTax;
console.log("The price of the phones after tax is:",priceTotal);

